import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/')({
  component: LightPatternsReport,
})

function LightPatternsReport() {
  return (
    <div className="light-report">
      {/* ── COVER ─────────────────────────────────────────────── */}
      <section className="cover-section">
        <div className="cover-meta">
          <span className="meta-pill">PHYSICS</span>
          <span className="meta-sep">·</span>
          <span className="meta-pill">WAVE OPTICS</span>
          <span className="meta-sep">·</span>
          <span className="meta-pill accent-blue">YEAR 11</span>
          <span className="meta-sep">·</span>
          <span className="meta-pill accent-pink">TERM 4</span>
        </div>
        <div className="cover-label">PROJECT-BASED LEARNING REPORT</div>
        <h1 className="cover-title">
          Light{' '}
          <span className="gradient-text">Patterns</span>
          <br />
          Project
        </h1>
        <p className="cover-sub">
          An investigation into how diffraction and interference of light reveal
          that light behaves as a wave — built around evidence, experiment, and
          observation.
        </p>
        <div className="driving-q-box">
          <span className="driving-label">▶ DRIVING QUESTION</span>
          <p className="driving-q">
            How do diffraction and interference show that light behaves like a
            wave?
          </p>
        </div>
        <div className="cover-dots">
          {[0, 1, 2, 3, 4].map((i) => (
            <span key={i} className={`dot ${i === 0 ? 'dot-active' : ''}`} />
          ))}
        </div>
      </section>

      {/* ── FOUNDATIONS ───────────────────────────────────────── */}
      <section className="content-section">
        <div className="section-tag">— FOUNDATIONS</div>
        <h2 className="section-title">
          What is a <span className="c-cyan">wave</span>, and why does it
          matter?
        </h2>
        <p className="section-intro">
          A wave is a disturbance that transfers energy without transferring
          matter. Two behaviours — diffraction and interference — only make
          sense if light moves as a wave. That is the foundation this project
          explores.
        </p>

        {/* Wave diagram */}
        <div className="wave-diagram-box">
          <svg viewBox="0 0 760 200" className="wave-svg" aria-hidden="true">
            <defs>
              <linearGradient id="wg" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#818cf8" />
                <stop offset="50%" stopColor="#a78bfa" />
                <stop offset="100%" stopColor="#f472b6" />
              </linearGradient>
            </defs>
            {/* amplitude arrow */}
            <line x1="60" y1="100" x2="60" y2="30" stroke="#fbbf24" strokeWidth="1.5" strokeDasharray="4 3" />
            <line x1="55" y1="30" x2="65" y2="30" stroke="#fbbf24" strokeWidth="1.5" />
            <text x="22" y="68" fill="#fbbf24" fontSize="12" fontFamily="system-ui">Amplitude</text>
            {/* wavelength arrow */}
            <line x1="120" y1="160" x2="310" y2="160" stroke="#38bdf8" strokeWidth="1.5" />
            <line x1="120" y1="155" x2="120" y2="165" stroke="#38bdf8" strokeWidth="1.5" />
            <line x1="310" y1="155" x2="310" y2="165" stroke="#38bdf8" strokeWidth="1.5" />
            <text x="170" y="178" fill="#38bdf8" fontSize="13" fontFamily="system-ui">Wavelength λ</text>
            {/* wave path */}
            <path
              d="M80,100 C110,30 150,30 190,100 C230,170 270,170 310,100 C350,30 390,30 430,100 C470,170 510,170 550,100 C590,30 630,30 670,100 C700,155 720,170 740,165"
              fill="none"
              stroke="url(#wg)"
              strokeWidth="3"
              strokeLinecap="round"
            />
          </svg>
        </div>

        {/* Key concept cards */}
        <div className="two-col-grid">
          <div className="concept-card">
            <div className="concept-card-title">Diffraction</div>
            <p className="concept-card-body">
              Light bends and spreads as it passes through narrow openings or
              around edges — something only waves do.
            </p>
          </div>
          <div className="concept-card">
            <div className="concept-card-title">Interference</div>
            <p className="concept-card-body">
              When two light waves overlap they either add up or cancel out,
              creating bright and dark patterns on a screen.
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="stats-row">
          <div className="stat-box">
            <div className="stat-num">≈ 400–700 nm</div>
            <div className="stat-label">Wavelength of visible light</div>
          </div>
          <div className="stat-box">
            <div className="stat-num">3 × 10⁸ m/s</div>
            <div className="stat-label">Speed of light in vacuum</div>
          </div>
          <div className="stat-box">
            <div className="stat-num">1801</div>
            <div className="stat-label">Year Young proved light is a wave</div>
          </div>
        </div>
      </section>

      {/* ── PHENOMENON I – DIFFRACTION ────────────────────────── */}
      <section className="content-section">
        <div className="section-tag">— PHENOMENON I</div>
        <h2 className="section-title">
          Diffraction —{' '}
          <span className="c-purple">light bends around edges</span>
        </h2>
        <p className="section-intro">
          When light passes through a narrow slit, it does not travel in
          straight lines. It spreads out behind the slit in curved fronts,
          exactly like water waves spreading after passing a gap in a harbour
          wall.
        </p>

        <div className="two-col-grid align-start">
          {/* Slit diagram */}
          <div className="diagram-box">
            <svg viewBox="0 0 340 220" className="slit-svg" aria-hidden="true">
              <defs>
                <linearGradient id="dg" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#818cf8" />
                  <stop offset="100%" stopColor="#a78bfa" />
                </linearGradient>
              </defs>
              {/* incoming parallel rays */}
              {[40, 65, 90, 115, 140, 165, 180].map((y, i) => (
                <line key={i} x1="10" y1={y} x2="130" y2={y} stroke="#818cf8" strokeWidth="1.2" opacity="0.7" />
              ))}
              {/* barrier */}
              <rect x="130" y="0" width="12" height="88" fill="#1e1b4b" />
              <rect x="130" y="132" width="12" height="88" fill="#1e1b4b" />
              <rect x="128" y="0" width="16" height="88" fill="none" stroke="#6366f1" strokeWidth="1" />
              <rect x="128" y="132" width="16" height="88" fill="none" stroke="#6366f1" strokeWidth="1" />
              {/* diffracted wavefronts (arcs) */}
              {[30, 55, 80, 105, 130].map((r, i) => (
                <path
                  key={i}
                  d={`M ${136 + r * Math.cos(Math.PI * 0.72)} ${110 - r * Math.sin(Math.PI * 0.72)} A ${r} ${r} 0 0 1 ${136 + r * Math.cos(-Math.PI * 0.72)} ${110 + r * Math.sin(Math.PI * 0.72)}`}
                  fill="none"
                  stroke="url(#dg)"
                  strokeWidth="1.2"
                  opacity={0.9 - i * 0.12}
                />
              ))}
              {/* labels */}
              <text x="12" y="200" fill="#a5b4fc" fontSize="11" fontFamily="system-ui">incoming light</text>
              <text x="175" y="30" fill="#c4b5fd" fontSize="11" fontFamily="system-ui">diffracted</text>
              <text x="175" y="44" fill="#c4b5fd" fontSize="11" fontFamily="system-ui">wavefronts</text>
            </svg>
          </div>

          {/* Why it proves wave behaviour */}
          <div>
            <div className="sub-heading">Why this proves wave behaviour</div>
            <p className="section-intro" style={{ marginBottom: '1rem' }}>
              If light were a stream of particles, it would simply punch a sharp
              shadow through the slit. Instead, the light spreads — and the
              narrower the slit, the wider the spread. Only waves do this.
            </p>
            <ul className="proof-list">
              <li>
                <span className="proof-dot cyan" />
                <div>
                  <strong>Slit narrower than λ</strong>
                  <br />
                  <span className="text-dim">Light spreads almost uniformly behind the opening.</span>
                </div>
              </li>
              <li>
                <span className="proof-dot purple" />
                <div>
                  <strong>Edges of objects</strong>
                  <br />
                  <span className="text-dim">Wavefronts curl around the boundary, softening the shadow.</span>
                </div>
              </li>
              <li>
                <span className="proof-dot pink" />
                <div>
                  <strong>Real-life evidence</strong>
                  <br />
                  <span className="text-dim">The colourful sheen on a CD or DVD is diffraction from microscopic grooves.</span>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* ── PHENOMENON II – INTERFERENCE ──────────────────────── */}
      <section className="content-section">
        <div className="section-tag">— PHENOMENON II</div>
        <h2 className="section-title">
          Interference —{' '}
          <span className="c-pink">when light waves meet</span>
        </h2>
        <p className="section-intro">
          Two waves overlapping in the same space combine. When their crests
          align they reinforce each other. When a crest meets a trough they
          cancel. The result is a pattern of bright and dark bands — a
          fingerprint of wave behaviour.
        </p>

        <div className="two-col-grid" style={{ marginBottom: '2rem' }}>
          {/* Constructive */}
          <div className="interference-card constructive">
            <div className="int-tag constructive-tag">CONSTRUCTIVE</div>
            <div className="int-title">Crest meets crest → bright fringe</div>
            <svg viewBox="0 0 280 80" className="int-svg" aria-hidden="true">
              <path d="M10,40 C30,10 50,10 70,40 C90,70 110,70 130,40 C150,10 170,10 190,40 C210,70 230,70 250,40 C260,25 268,18 272,14" fill="none" stroke="#22d3ee" strokeWidth="2" />
              <path d="M10,40 C30,10 50,10 70,40 C90,70 110,70 130,40 C150,10 170,10 190,40 C210,70 230,70 250,40 C260,25 268,18 272,14" fill="none" stroke="#4ade80" strokeWidth="2" strokeDasharray="5 3" opacity="0.7" />
              <text x="60" y="76" fill="#4ade80" fontSize="10" fontFamily="system-ui">Resultant: 2× amplitude</text>
            </svg>
            <p className="int-note">Path difference = nλ. Waves arrive in phase, amplitudes add together.</p>
          </div>

          {/* Destructive */}
          <div className="interference-card destructive">
            <div className="int-tag destructive-tag">DESTRUCTIVE</div>
            <div className="int-title">Crest meets trough → dark fringe</div>
            <svg viewBox="0 0 280 80" className="int-svg" aria-hidden="true">
              <path d="M10,40 C30,10 50,10 70,40 C90,70 110,70 130,40 C150,10 170,10 190,40 C210,70 230,70 250,40 C260,25 268,18 272,14" fill="none" stroke="#818cf8" strokeWidth="2" />
              <path d="M10,40 C30,70 50,70 70,40 C90,10 110,10 130,40 C150,70 170,70 190,40 C210,10 230,10 250,40 C260,55 268,62 272,66" fill="none" stroke="#f472b6" strokeWidth="2" strokeDasharray="5 3" opacity="0.7" />
              <line x1="10" y1="40" x2="272" y2="40" stroke="#f87171" strokeWidth="1.5" strokeDasharray="6 4" />
              <text x="50" y="76" fill="#f87171" fontSize="10" fontFamily="system-ui">Resultant: zero — cancellation</text>
            </svg>
            <p className="int-note">Path difference = (n + ½)λ. Waves arrive out of phase, they cancel out.</p>
          </div>
        </div>

        {/* Young's Double-Slit */}
        <div className="sub-heading">Young's Double-Slit Experiment</div>
        <div className="diagram-box wide-diagram">
          <svg viewBox="0 0 640 240" className="young-svg" aria-hidden="true">
            <defs>
              <linearGradient id="lg-laser" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#818cf8" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#818cf8" stopOpacity="0" />
              </linearGradient>
            </defs>
            {/* Laser box */}
            <rect x="20" y="105" width="64" height="30" rx="4" fill="#4f46e5" />
            <text x="36" y="125" fill="white" fontSize="12" fontFamily="system-ui">Laser</text>
            {/* beam */}
            <rect x="84" y="118" width="160" height="4" fill="url(#lg-laser)" />
            <line x1="84" y1="120" x2="244" y2="120" stroke="#818cf8" strokeWidth="2" />
            {/* barrier + slits */}
            <rect x="244" y="0" width="10" height="104" fill="#1e1b4b" stroke="#6366f1" strokeWidth="1" />
            <rect x="244" y="136" width="10" height="104" fill="#1e1b4b" stroke="#6366f1" strokeWidth="1" />
            <text x="226" y="16" fill="#94a3b8" fontSize="10" fontFamily="system-ui" textAnchor="middle">double slit</text>
            <line x1="249" y1="18" x2="249" y2="104" stroke="#94a3b8" strokeWidth="0.8" strokeDasharray="3 2" />
            {/* rays to screen */}
            {[
              [249, 108, 580, 20],
              [249, 108, 580, 60],
              [249, 108, 580, 100],
              [249, 108, 580, 120],
              [249, 108, 580, 140],
              [249, 132, 580, 100],
              [249, 132, 580, 120],
              [249, 132, 580, 140],
              [249, 132, 580, 180],
              [249, 132, 580, 220],
            ].map(([x1, y1, x2, y2], i) => (
              <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#f472b6" strokeWidth="0.8" opacity="0.55" />
            ))}
            {/* screen */}
            <rect x="580" y="0" width="12" height="240" fill="#0f172a" stroke="#334155" strokeWidth="1" />
            {/* fringe pattern */}
            {[
              { y: 0, h: 18, bright: false },
              { y: 18, h: 24, bright: true },
              { y: 42, h: 18, bright: false },
              { y: 60, h: 24, bright: true },
              { y: 84, h: 18, bright: false },
              { y: 102, h: 30, bright: true },
              { y: 132, h: 30, bright: true },
              { y: 162, h: 18, bright: false },
              { y: 180, h: 24, bright: true },
              { y: 204, h: 18, bright: false },
              { y: 222, h: 18, bright: true },
            ].map(({ y, h, bright }, i) => (
              <rect key={i} x="592" y={y} width="12" height={h} fill={bright ? '#22d3ee' : '#0a0e1a'} opacity={bright ? 0.9 : 1} />
            ))}
            <text x="612" y="122" fill="#94a3b8" fontSize="10" fontFamily="system-ui">screen →</text>
          </svg>
        </div>

        {/* formula */}
        <div className="formula-box">
          <div className="formula-text">d sin θ = mλ</div>
          <p className="formula-note">
            For bright fringes, the path difference between the two slits equals
            an integer multiple of the wavelength. Measuring the fringe spacing
            gives a direct value for <strong>λ</strong> — confirming light's
            wavelength.
          </p>
        </div>
      </section>

      {/* ── REAL-LIFE EXAMPLES ────────────────────────────────── */}
      <section className="content-section">
        <div className="section-tag">— REAL-LIFE EXAMPLES</div>
        <h2 className="section-title">
          Wave behaviour <span className="c-cyan">everywhere you look</span>
        </h2>
        <p className="section-intro">
          Diffraction and interference are not just laboratory curiosities. They
          shape colour, drive modern technology, and explain everyday optical
          effects — here are six of the most striking examples.
        </p>

        <div className="examples-grid">
          {[
            {
              icon: '💿',
              title: 'CDs & DVDs',
              tag: 'Diffraction',
              tagColor: 'cyan',
              body: 'Microscopic spiral grooves (~1.6 µm apart) act as a diffraction grating, splitting white light into a rainbow of colours as you tilt the disc.',
            },
            {
              icon: '🫧',
              title: 'Soap Bubbles',
              tag: 'Interference',
              tagColor: 'purple',
              body: 'Thin soap films create path differences between light reflected from the inner and outer surfaces, producing vivid, shifting colour bands.',
            },
            {
              icon: '🦚',
              title: 'Peacock Feathers',
              tag: 'Interference',
              tagColor: 'purple',
              body: 'Nanostructured barbules in feathers cause constructive interference at specific wavelengths, producing iridescent blues and greens with no pigment at all.',
            },
            {
              icon: '🔭',
              title: 'Anti-Reflective Lenses',
              tag: 'Interference',
              tagColor: 'pink',
              body: 'A thin MgF₂ coating on camera and spectacle lenses is tuned so that reflections from its two surfaces cancel via destructive interference, cutting glare.',
            },
            {
              icon: '🌫️',
              title: 'Laser Pointers & Fog',
              tag: 'Diffraction',
              tagColor: 'cyan',
              body: 'Shining a laser through mist or a frosted window scatters light via diffraction, forming circular haloes whose ring spacing reveals droplet size.',
            },
            {
              icon: '🖼️',
              title: 'Holograms',
              tag: 'Both',
              tagColor: 'gradient',
              body: 'Security holograms record an interference pattern of laser light. Illuminating the hologram re-creates the 3-D wave-field via diffraction, reconstructing the image.',
            },
          ].map(({ icon, title, tag, tagColor, body }) => (
            <div key={title} className="example-card">
              <div className="example-icon">{icon}</div>
              <div className="example-header">
                <span className={`example-tag tag-${tagColor}`}>{tag}</span>
                <h3 className="example-title">{title}</h3>
              </div>
              <p className="example-body">{body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── CONCLUSION ────────────────────────────────────────── */}
      <section className="content-section conclusion-section">
        <div className="section-tag">— CONCLUSION</div>
        <h2 className="section-title">
          The wave nature of light,{' '}
          <span className="gradient-text">confirmed</span>
        </h2>
        <p className="section-intro">
          Across this project the agent investigated two phenomena that cannot
          be explained by particles alone. Diffraction reveals that light
          spreads around obstacles, and interference shows that overlapping light
          beams can either reinforce or cancel each other. Both behaviours appear
          in everyday objects — from films, CDs, feathers, lens coatings —
          making the case overwhelming. Light, at least in these experiments,
          behaves convincingly as a wave.
        </p>

        <div className="conclusion-grid">
          {[
            { icon: '🫧', title: 'Soap Bubbles', desc: 'Thin-film interference creates vivid colour bands visible to the naked eye.' },
            { icon: '💿', title: 'CDs & DVDs', desc: 'Groove diffraction produces the characteristic rainbow sheen on reflective discs.' },
            { icon: '🦚', title: 'Peacock Feathers', desc: 'Nanostructures produce iridescence through constructive interference, not pigment.' },
            { icon: '🔭', title: 'Anti-reflective lenses', desc: 'Destructive interference in thin coatings on glass to prevent reflection.' },
            { icon: '🌫️', title: 'Laser pointers & silos', desc: 'Diffraction pattern size reveals the width of a slit or particle to the wall.' },
            { icon: '🖼️', title: 'Holograms', desc: 'An interference pattern stores, and diffraction reconstructs, a full 3-D image.' },
          ].map(({ icon, title, desc }) => (
            <div key={title} className="conclusion-card">
              <div className="concl-icon">{icon}</div>
              <div className="concl-title">{title}</div>
              <p className="concl-desc">{desc}</p>
            </div>
          ))}
        </div>

        <div className="footer-row">
          <span className="footer-name">Light Patterns Project</span>
          <span className="footer-sep">·</span>
          <span className="footer-date">2025–2026 · Term 4 · Due 15 May</span>
        </div>
      </section>
    </div>
  )
}
