# AGENTS.md

## Project Overview

A single-page physics report — "Light Patterns Project" — that consolidates five previously separate pages (cover, foundations, diffraction, interference, conclusion) into one continuous scrollable document with a consistent dark-theme design. Includes a real-life examples section. Built with TanStack Start and deployed on Netlify.

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | TanStack Start |
| Frontend | React 19, TanStack Router v1 |
| Build | Vite 7 |
| Styling | Tailwind CSS 4 + custom CSS |
| Language | TypeScript 5.7 (strict) |
| Deployment | Netlify |

## Directory Structure

```
src/
  routes/
    __root.tsx        # Root HTML shell (title, global styles)
    index.tsx         # Entire report rendered as one component
  styles.css          # All report CSS (dark theme, section layout, inline SVG diagrams)
  data/
    products.ts       # Legacy scaffold file — unused
  router.tsx          # TanStack Router setup
public/               # Static assets (favicon)
```

## Architecture Decisions

- **Single route (`/`)** — the entire report lives in `src/routes/index.tsx`. No sub-routes are needed.
- **Inline SVGs** — wave diagrams, slit diagrams, and the Young's double-slit experiment are rendered as inline SVG inside the React component. This keeps visuals crisp at all resolutions with no asset management overhead.
- **CSS in `styles.css`** — all custom styles use plain CSS class names defined in `src/styles.css` alongside the Tailwind import. Tailwind utilities are deliberately avoided inside the report component so styling stays in one place.
- **No external UI library** — no Radix UI or shadcn components; the design is fully self-contained.
- **No Header component** — the root layout has no navigation header, intentionally removed so no product-marketing chrome appears on an academic report.

## Report Sections (in order)

1. **Cover** — title, driving question, metadata pills
2. **Foundations** — wave definition, animated wave SVG, key stats
3. **Phenomenon I: Diffraction** — slit diagram, wave-behaviour proof list
4. **Phenomenon II: Interference** — constructive/destructive cards, Young's double-slit SVG, formula
5. **Real-life Examples** — six cards (CDs, soap bubbles, peacock feathers, anti-reflective lenses, laser/fog, holograms)
6. **Conclusion** — summary grid, footer

## Coding Conventions

- Components: PascalCase
- CSS classes: kebab-case (`section-title`, `example-card`, etc.)
- TypeScript strict mode; `@/` alias resolves to `src/`
- No comments in component code — naming is self-documenting

## Development Commands

```bash
npm run dev      # Start dev server (port 3000)
netlify dev      # Start with Netlify emulation (port 8888)
npm run build    # Production build → dist/client/
```
