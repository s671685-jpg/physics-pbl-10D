# Light Patterns Project

A single-page interactive physics report investigating how diffraction and interference of light reveal that light behaves as a wave. Built with TanStack Start and deployed on Netlify.

## Key Technologies

| Layer | Technology |
|-------|-----------|
| Framework | TanStack Start |
| Frontend | React 19, TanStack Router v1 |
| Build | Vite 7 |
| Styling | Tailwind CSS 4 + custom CSS |
| Language | TypeScript 5.7 (strict) |
| Deployment | Netlify |

## Running Locally

```bash
npm install
npm run dev
```

The dev server starts at `http://localhost:3000` (or port 8888 via `netlify dev`).

## Building

```bash
npm run build
```

Output is written to `dist/client/`.
